import pyximport;pyximport.install()
import helloworld
helloworld.showimg()