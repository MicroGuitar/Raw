// #include "tbb/task_scheduler_init.h"
// #include "tbb/blocked_range.h"
// #include "tbb/parallel_for.h"
#include "time.h"
#include "stdio.h"
#include <opencv2/opencv.hpp>
#include <iostream>
#include <cstdlib>

// using namespace tbb;

/*************gcc tbb_read.cpp -ltbb -std=c++11 -lstdc++ -o tbb_read************/
class Body : public cv::ParallelLoopBody
{
    unsigned char *const my_a;
    short *const dst;
    const int Length_12 = 1843200;

  public:
    void operator()(const cv::Range &r) const
    {
        unsigned char *a = my_a;
        short *b = dst;
        short int p0 = 0;
        short int p1 = 0;
        unsigned char px_bytes[3] = {0};
        size_t i, j = 0;
        printf("coming\n");
        int k = r.start;
        int e = r.end;

        for (i = r.start, j = r.start / 1.5; i != r.end; j = j + 8, i = i + 12)
        {
            px_bytes[0] = a[i];
            px_bytes[1] = a[i + 1];
            px_bytes[2] = a[i + 2];
            p0 = ((px_bytes[0] << 4) | (px_bytes[1] & 0x0F)) << 4;
            p1 = ((px_bytes[2] << 4) | ((px_bytes[1] >> 4) & 0x0F)) << 4;

            b[j] = p0;
            b[j + 1] = p1;

            px_bytes[0] = a[i + 3];
            px_bytes[1] = a[i + 4];
            px_bytes[2] = a[i + 5];
            p0 = ((px_bytes[0] << 4) | (px_bytes[1] & 0x0F)) << 4;
            p1 = ((px_bytes[2] << 4) | ((px_bytes[1] >> 4) & 0x0F)) << 4;

            b[j + 2] = p0;
            b[j + 3] = p1;

            px_bytes[0] = a[i + 6];
            px_bytes[1] = a[i + 7];
            px_bytes[2] = a[i + 8];
            p0 = ((px_bytes[0] << 4) | (px_bytes[1] & 0x0F)) << 4;
            p1 = ((px_bytes[2] << 4) | ((px_bytes[1] >> 4) & 0x0F)) << 4;

            b[j + 4] = p0;
            b[j + 5] = p1;

            px_bytes[0] = a[i + 9];
            px_bytes[1] = a[i + 10];
            px_bytes[2] = a[i + 11];
            p0 = ((px_bytes[0] << 4) | (px_bytes[1] & 0x0F)) << 4;
            p1 = ((px_bytes[2] << 4) | ((px_bytes[1] >> 4) & 0x0F)) << 4;

            b[j + 6] = p0;
            b[j + 7] = p1;           

        }
    }
    Body(unsigned char a[], short b[])
        : my_a(a), dst(b)
    {
    }
};

int main()
{
    const int R = 1280;
    const int L = 960;
    const int Length_12 = 1843200;
    double total;
    clock_t start, end;
    const char *file_name = "../1.RAW";
    FILE *fp;
    fp = fopen(file_name, "rb");
    unsigned char Raw[Length_12];
    short int img[1228800];
    double nstrips = 1;
    std::cout << nstrips << std::endl;
    start = clock();
    if (fp == NULL)
    {
        printf("can not open file\n");
    }
    fread(Raw, sizeof(unsigned char), Length_12, fp);
    fclose(fp);

    cv::parallel_for_(cv::Range(0, 1843200), Body(Raw, img), nstrips);

    end = clock();
    printf("%d\n", img[0]);
    total = (double)(end - start) / CLOCKS_PER_SEC;
    printf("%f \n", total);

    cv::Mat image(L, R, CV_16UC1, img);
    cv::imshow("Image", image);
    cv::waitKey(0);
    return 0;
}