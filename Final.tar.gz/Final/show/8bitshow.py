import numpy as np
import cv2

imgData = np.fromfile('2.RAW',np.uint8)

imgData = imgData.reshape(960,-1)

cv2.imshow('img',imgData)
cv2.waitKey()
cv2.destroyAllWindows() 

