#usr/bin/bash
./demoWithCamera.py
