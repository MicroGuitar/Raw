sudo cp libMVSDK.so /usr/lib/
