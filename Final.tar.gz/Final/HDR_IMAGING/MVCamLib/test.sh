#!/bin/bash
make clean
make
python MVCam.py